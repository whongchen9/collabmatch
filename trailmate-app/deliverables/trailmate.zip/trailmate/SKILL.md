---
name: trailmate
description: |
  This skill provides patterns for building outdoor activity apps with GPS maps (Leaflet/react-leaflet),
  checkpoint-based check-in, real-time GPS track recording, and automatic activity log generation
  with stats. Use when building interactive maps with markers and polyline tracks,
  geolocation-based check-in with photo upload, Haversine distance calculations, GPS track
  collection and replay, automatic log generation from activity data, or team-based outdoor coordination.
  Triggers include maps, GPS tracking, check-in, hiking, trail log, checkpoint, Leaflet, Haversine.
agent_created: true
---

# TrailMate — 户外活动地图/签到/日志技能

## Overview

This skill encapsulates the production-tested patterns from TrailMate — a full-stack hiking companion app.
It covers three interconnected workflows: **Map & GPS Tracking**, **Check-in (签到打卡)**, and **Activity Log Generation (TrailLog)**.

## When to Use

Activate this skill when building or adding features for:

- Interactive maps with markers, polylines, and user location tracking
- GPS position collection at intervals with Haversine distance stats
- Checkpoint-based check-in with photo upload and text notes
- Automatic activity log generation with stats (distance, duration, pace)
- Team-based outdoor or location-aware coordination
- Trail/route replay on read-only mini-maps

## Core Capabilities

### 1. Map & GPS Tracking

Build interactive maps with Leaflet via `react-leaflet` v4. The full pattern is in `references/map-patterns.md`.

**Quick start dependencies:**
```
leaflet, react-leaflet, @types/leaflet
```

**Key patterns to follow:**
- Use `MapContainer` + `TileLayer` for the base; switch tiles for dark mode
- GPS collection loop: `setInterval` at 15s, `enableHighAccuracy: true`, silent fail on error
- Store track points in Zustand store as `{lat, lng, timestamp}[]`
- Render track as `<Polyline>` with `color: '#3B82FD', weight: 4, opacity: 0.5`
- Compute distance with Haversine formula (implementation in `references/map-patterns.md`)
- Reverse geocode via Nominatim API (throttle to 1 req/s)

**When implementing a map feature, always:**
1. Load `references/map-patterns.md` for component architecture, GPS loop, and distance utils
2. Follow the three-tier map model: small sidebar map → full interactive map → read-only replay map
3. Handle dark mode tile URLs with a theme-aware switch

### 2. Check-in (签到打卡)

Implement checkpoint-based check-in with photo upload and GPS verification. Full workflow in `references/checkin-workflow.md`.

**Lifecycle:**
```
Leader creates checkpoints → Hike starts → Members check in at each point
→ Photos + notes attached → Progress tracked per-member → Logs generated on completion
```

**Key patterns to follow:**
- Checkpoints stored in `Group.checkpoints[]` with nested `checkins[]`
- Check-in API verifies GPS proximity to checkpoint, returns distance
- Photos auto-compressed to 800px width before upload
- Progress view: sort checkpoints by distance, highlight next unchecked, per-member progress bars
- Three panel states: idle / hiking / completed — each with distinct header styling

**When implementing check-in, always:**
1. Load `references/checkin-workflow.md` for data model, API flow, and progress UI
2. Load `references/data-models.md` for type definitions
3. Use the `Checkpoint` type with `type: 'meeting' | 'start' | 'checkpoint' | 'end'`

### 3. Activity Log Generation (TrailLog)

Auto-generate rich activity logs with GPS stats, check-in records, photos, and replay. Full workflow in `references/log-generation.md`.

**Two-phase generation:**
```
Phase 1 (on hike start): Batch-create blank logs for all members
Phase 2 (on hike end): Populate with GPS stats, check-ins, photos per user
```

**Stats to compute:**
- `totalDistance` — sum of Haversine between all track points (meters)
- `movingDuration` — time span from first to last track point (seconds)
- `avgPace` — seconds per km, formatted as `X'XX"`

**Log display includes:**
- Year/month grouping with collapsible sections
- GPS track replay on read-only Leaflet mini-map
- Star rating, notes, check-in timeline, photo grid
- Share via native Share API or clipboard
- Edit/delete with optimistic UI updates

**When generating logs, always:**
1. Load `references/log-generation.md` for the two-phase flow, stats formulas, and display patterns
2. Use the `TrailLog` type from `references/data-models.md`
3. Format pace as `Math.floor(s/km / 60) + "'" + String(s/km % 60).padStart(2, '0') + "\""`

## Reference Files

All detailed documentation is in `references/`. Load them as needed — do not load all at once.

| File | Contents | When to Load |
|------|----------|-------------|
| `references/map-patterns.md` | Map component tiers, GPS loop, Haversine, tiles, markers, Nominatim | Building any map/GPS feature |
| `references/checkin-workflow.md` | Checkpoint CRUD, check-in API, photo upload, progress tracking | Building check-in flow |
| `references/log-generation.md` | Two-phase generation, stats math, display UI, sharing | Building TrailLog feature |
| `references/data-models.md` | All TypeScript types, Zustand store, API layer, utility functions | Need type definitions or API patterns |

## Design Conventions (from TrailMate)

- **Tech stack**: React 18 + TypeScript + Vite + Tailwind CSS + Zustand + Leaflet
- **State**: Single Zustand store with slices (auth, groups, intents, matching, track)
- **Styling**: Tailwind utility classes, `dark:` prefix for dark mode, `bg-[#faf7f2] dark:bg-gray-950` base
- **Animation**: `animate-slide-in-right` for sidebars, `animate-slideDown` for toasts, `active:scale-95` for buttons
- **API**: Token-based auth via `Authorization: Bearer`, centralized `api<T>()` wrapper with 401 auto-logout
- **Guest mode**: `guest_` prefixed tokens skip auth header
- **Mobile-first**: `max-w-lg mx-auto` to constrain desktop width
- **Card pattern**: `bg-white dark:bg-gray-900 rounded-2xl shadow-sm dark:shadow-gray-900/50`
- **Header pattern**: Green gradient head card (`from-emerald-500 to-teal-600`) + white card sections with `border-l-4` color strips
- **Empty states**: Always provide CTA ("开始你的第一次徒步") with inline illustrations

## Quick Implementation Guide

When asked to build a complete outdoor activity feature, follow this order:

1. **Define data models** — use types from `references/data-models.md`, adapt as needed
2. **Set up map** — `MapContainer` + `TileLayer` + GPS collection loop from `references/map-patterns.md`
3. **Add checkpoints** — long-press/click to create, markers to view, per `references/checkin-workflow.md`
4. **Implement check-in** — GPS verify + photo compress + progress tracking
5. **Build stats** — Haversine total distance + duration + pace from track array
6. **Generate logs** — two-phase pattern from `references/log-generation.md`
7. **Display logs** — month grouping, mini-map replay, share, edit/delete
