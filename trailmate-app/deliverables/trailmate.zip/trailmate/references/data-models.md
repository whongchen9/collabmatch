# Data Models & State Management

## Zustand Store Architecture

Single global store with distinct slices. All state is managed in `src/store/index.ts`.

```typescript
interface AppState {
  // ── Authentication ──
  user: User | null;
  isLoggedIn: boolean;
  loginLoading: boolean;

  // ── Data ──
  groups: Group[];       // My teams
  intents: Intent[];     // My match intents

  // ── Matching Flow ──
  matching: MatchingState;

  // ── GPS Track (global buffer) ──
  track: TrackPoint[];

  // ── Actions ──
  login(email, password): Promise<void>;
  register(name, email, password): Promise<void>;
  logout(): void;
  loadUser(): Promise<void>;
  loadGroups(): Promise<void>;
  loadIntents(): Promise<void>;
  loadAll(): Promise<void>;
  setMatching(partial: Partial<MatchingState>): void;
  resetMatching(): void;
  addTrackPoint(point: TrackPoint): void;
  clearTrack(): void;
  showToast(message: string, type?: 'success' | 'error'): void;
}
```

## Core Types

### User

```typescript
interface User {
  id: string;
  name: string;
  email?: string;
  bio?: string;
  avatar?: string;
  avatarColor?: string;
  hikeFrequency?: string;       // 'often' | 'sometimes' | 'rarely'
  creditScore?: number;
  hikeCount?: number;
  totalDistance?: number;       // meters
  emergencyContacts?: EmergencyContact[];
  userPrompts?: UserPrompt[];
  resources?: UserResource[];
}
```

### Group (Team)

```typescript
interface Group {
  id: string;
  name: string;
  description?: string;
  status: 'forming' | 'ready' | 'ongoing';
  hikeStatus: 'idle' | 'hiking' | 'completed';
  creatorId: string;
  members: GroupMember[];
  maxMembers: number;
  essentials?: GroupEssentials;
  prompts?: string[];
  plan?: string;
  checkpoints: Checkpoint[];
  messages: GroupMessage[];
  locations: MemberLocation[];
  photos: Photo[];
  matchingEnabled: boolean;
  shareToken?: string;
  createdAt: string;
}

interface GroupMember {
  id: string;
  name: string;
  avatar?: string;
  avatarColor?: string;
  role: 'leader' | 'member';
}

interface GroupEssentials {
  location?: string;
  date?: string;
  days?: number;
  difficulty?: string;
  activity?: string;
}
```

### Intent (Matching)

```typescript
interface Intent {
  id: string;
  rawInput: string;
  essentials: GroupEssentials;
  prompts: string[];
  status: 'matching' | 'matched' | 'teaming' | 'confirmed' | 'expired';
  matchedUsers: MatchedUser[];
  matchedTeams: MatchedTeam[];
  userId: string;
  createdAt: string;
}
```

### TrailLog

```typescript
interface TrailLog {
  id: string;
  type: 'hike' | 'other';
  title: string;
  date: string;            // YYYY-MM-DD
  location?: string;
  distance?: number;       // km (planned)
  duration?: number;       // hours (planned)
  notes?: string;
  photos?: string[];
  rating?: number;         // 1-5
  checkpoints?: CheckpointRecord[];
  track?: TrackPoint[];
  totalDistance?: number;  // meters (GPS actual)
  movingDuration?: number; // seconds (GPS actual)
  avgPace?: number;        // seconds/km
  groupId?: string;
}
```

### Classic Route (山志图鉴)

```typescript
interface ClassicRoute {
  id: string;
  name: string;
  location: string;
  difficulty: 'easy' | 'moderate' | 'hard' | 'extreme';
  distance: number;          // km
  elevation: number;         // meters
  duration: number;          // hours (estimated)
  checkpoints: RouteCheckpoint[];
  titles: RouteTitle[];      // bronze/silver/gold/hidden
  comments: RouteComment[];
  tags: string[];
  story: string;
  guide: string;
  coverImage?: string;
}

interface RouteCheckpoint {
  label: string;
  lat: number;
  lng: number;
  order: number;
  tip?: string;
}

interface RouteTitle {
  name: string;
  tier: 'bronze' | 'silver' | 'gold' | 'hidden';
  condition: string;
  icon: string;
}
```

## API Layer Pattern

### Base setup

```typescript
const API_BASE = import.meta.env.VITE_API_BASE || '/api';
let token: string | null = localStorage.getItem('trailmate_token');

async function api<T>(path: string, opts: RequestInit = {}): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(opts.headers as Record<string, string> || {}),
  };

  // Guest mode: guest_ prefixed tokens skip auth header
  if (token && !token.startsWith('guest_')) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const res = await fetch(`${API_BASE}${path}`, { ...opts, headers });

  if (res.status === 401) {
    setToken(null);
    window.dispatchEvent(new CustomEvent('unauthorized'));
    throw new Error('登录已过期');
  }

  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.message || body.error || '请求失败');
  }

  return res.json();
}
```

### API module organization

```typescript
export const authApi = {
  login: (email, password) => api.post('/auth/login', { email, password }),
  register: (name, email, password) => api.post('/auth/register', { name, email, password }),
  githubOAuth: (code) => api.post('/auth/github', { code }),
  getMe: () => api.get<User>('/auth/me'),
  forgotPassword: (email) => api.post('/auth/forgot', { email }),
  resetPassword: (token, password) => api.post('/auth/reset', { token, password }),
};

export const groupsApi = {
  list: () => api.get<Group[]>('/groups'),
  get: (id) => api.get<Group>(`/groups/${id}`),
  create: (data) => api.post<Group>('/groups', data),
  update: (id, data) => api.put<Group>(`/groups/${id}`, data),
  join: (id) => api.post(`/groups/${id}/join`),
  leave: (id) => api.post(`/groups/${id}/leave`),
  checkin: (id, cpIndex, lat, lng) =>
    api.post(`/groups/${id}/checkin`, { checkpointIndex: cpIndex, lat, lng }),
  reportLocation: (id, lat, lng) =>
    api.post(`/groups/${id}/location`, { lat, lng }),
  sos: (id, lat, lng, message) =>
    api.post(`/groups/${id}/sos`, { lat, lng, message }),
  // ... more methods
};

export const traillogsApi = {
  list: () => api.get<TrailLog[]>('/traillogs'),
  get: (id) => api.get<TrailLog>(`/traillogs/${id}`),
  update: (id, data) => api.put<TrailLog>(`/traillogs/${id}`, data),
  delete: (id) => api.delete(`/traillogs/${id}`),
  generateFromGroup: (groupId) =>
    api.post(`/groups/${groupId}/generate-logs`),
  generateForUser: (groupId, userId, data) =>
    api.post(`/groups/${groupId}/generate-log/${userId}`, data),
};
```

## Utility Functions

```typescript
// Tailwind class merge
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Haversine distance (meters)
export function haversineDistance(lat1, lng1, lat2, lng2): number;

// HTML sanitization
export function sanitizeHTML(html: string): string;

// Date formatting
export function formatDate(date: string | Date): string;
export function formatDuration(seconds: number): string;
export function formatPace(secondsPerKm: number): string;
```
