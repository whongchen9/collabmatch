# TrailLog (活动日志) Generation

## Overview

When a team hike completes, a TrailLog is automatically generated for each member. The log captures the full experience: GPS track, check-in records, stats, photos, and notes.

## Data Model

```typescript
interface TrailLog {
  id: string;
  type: 'hike' | 'other';
  title: string;            // Auto-generated from group name
  date: string;             // YYYY-MM-DD
  location?: string;        // Start point name
  distance?: number;        // Straight-line distance (km)
  duration?: number;        // Planned duration (hours)
  notes?: string;           // User notes
  photos?: string[];        // All photos from group
  rating?: number;          // 1-5 stars
  checkpoints?: CheckpointRecord[];  // User's check-in history
  track?: TrackPoint[];     // Full GPS track
  totalDistance?: number;   // Actual GPS distance (meters)
  movingDuration?: number;  // Actual moving time (seconds)
  avgPace?: number;         // Average pace (seconds/km)
}

interface CheckpointRecord {
  label: string;
  checkedInAt: number;  // timestamp
  notes?: string;
  photos?: string[];
}
```

## Generation Flow

### Two-phase generation

```
Phase 1: On hike START (leader action)
  → traillogsApi.generateFromGroup(groupId)
  → Creates blank logs for all members
  → Sets title, date, location, team info

Phase 2: On hike COMPLETE (per-member)
  → traillogsApi.generateForUser(groupId, userId, data)
  → Populates stats, track, check-ins, photos
  → Overwrites the blank log from Phase 1
```

### Phase 1 — Batch log creation

```typescript
// useTeamChat.ts — handleGo()
const handleGo = async () => {
  // ... 3-2-1 countdown ...
  await groupsApi.update(id, { hikeStatus: 'hiking' });
  await groupsApi.reportLocation(id, lat, lng);

  // Create blank logs for all members
  await traillogsApi.generateFromGroup(id);
};
```

API: `POST /groups/{id}/generate-logs`

### Phase 2 — Per-user log finalization

```typescript
// useTeamChat.ts — doComplete()
const doComplete = async () => {
  // 1. Calculate GPS stats from track[]
  let totalDistance = 0;
  for (let i = 1; i < track.length; i++) {
    totalDistance += haversineDistance(
      track[i-1].lat, track[i-1].lng,
      track[i].lat, track[i].lng
    );
  }

  const movingDuration = track.length >= 2
    ? (track[track.length - 1].timestamp - track[0].timestamp) / 1000
    : 0;

  const avgPace = totalDistance > 0
    ? movingDuration / (totalDistance / 1000)
    : 0;

  // 2. Collect user's check-in records
  const checkpointRecords = groupData.checkpoints
    .filter(cp => cp.checkins.some(c => c.userId === user.id))
    .map(cp => {
      const myCheckin = cp.checkins.find(c => c.userId === user.id)!;
      return {
        label: cp.label || `打卡点`,
        checkedInAt: myCheckin.checkedInAt,
        notes: myCheckin.notes || '',
        photos: myCheckin.photos || [],
      };
    });

  // 3. Generate log via API
  await traillogsApi.generateForUser(id, user.id, {
    distance: checkpointDistance,     // straight-line start→end (km)
    duration: checkpointDuration,     // first→last check-in (minutes)
    checkpointRecords,
    totalDistance,                    // GPS actual (meters)
    movingDuration,                   // GPS actual (seconds)
    avgPace,                          // seconds/km
    track,                            // full [{lat,lng,timestamp}]
  });

  // 4. Mark hike as completed
  await groupsApi.update(id, { hikeStatus: 'completed' });

  // 5. Clear local track buffer
  clearTrack();
};
```

API: `POST /groups/{id}/generate-log/{userId}`

## Stats Calculation

### GPS-based (preferred — from track[])

```typescript
// Total distance: sum of Haversine between consecutive points
let totalDistance = 0;
for (let i = 1; i < track.length; i++) {
  totalDistance += haversineDistance(
    track[i-1].lat, track[i-1].lng,
    track[i].lat, track[i].lng
  );
}
// Result: meters

// Moving duration: time span of track
const movingDuration = track.length >= 2
  ? (track[track.length - 1].timestamp - track[0].timestamp) / 1000
  : 0;
// Result: seconds

// Average pace
const distanceKm = totalDistance / 1000;
const paceSecondsPerKm = totalDistance > 0
  ? movingDuration / distanceKm
  : 0;
// Result: seconds/km

// Pace formatting for display
const paceMin = Math.floor(paceSecondsPerKm / 60);
const paceSec = Math.floor(paceSecondsPerKm % 60);
const paceDisplay = `${paceMin}'${String(paceSec).padStart(2, '0')}"`;
// Example: "8'30"" = 8 min 30 sec per km
```

### Checkpoint-based (fallback)

```typescript
// Straight-line distance: first checkpoint → last checkpoint
const startCp = userCheckins[0];
const endCp = userCheckins[userCheckins.length - 1];
const distance = haversineDistance(
  startCp.lat, startCp.lng,
  endCp.lat, endCp.lng
) / 1000; // km

// Duration: time between first and last check-in
const duration = (endCp.checkedInAt - startCp.checkedInAt) / 60000; // minutes
```

## CompleteModal — Pre-completion Summary

Before finalizing, the CompleteModal shows:

```tsx
<CompleteModal
  distance={formatDistance}        // "12.5 km"
  duration={formatDuration}        // "3h 20min"
  checkpoints={completedCount}     // "5/7 打卡点"
  avgPace={formatPace}            // "8'30" /km"
  onConfirm={handleComplete}
  onCancel={handleCancel}
/>
```

## HikeLog Page — Display

### Structure

```
HikeLog Page
├── Year tabs (2024 | 2025 | 2026)
├── Stats bar
│   ├── 总里程 (km)
│   ├── 总次数
│   └── 总时长 (hours)
├── Monthly groups (collapsible)
│   └── Month header (e.g., "2025年6月 · 3次")
│       └── Log card[]
│           ├── Title + date
│           ├── Star rating (1-5)
│           ├── Notes text
│           ├── GPS track replay (Leaflet mini-map + Polyline)
│           ├── Track stats card (blue):
│           │   ├── 总里程
│           │   ├── 运动时长
│           │   └── 平均配速
│           ├── Check-in records (time + note + photos)
│           ├── Photo grid
│           ├── Share button (WeChat / clipboard)
│           └── Edit / Delete buttons
└── Empty state: "还没有活动记录"
```

### Track replay in log

```tsx
{log.track && log.track.length > 1 && (
  <div className="h-48 rounded-xl overflow-hidden">
    <MapContainer
      center={[log.track[0].lat, log.track[0].lng]}
      zoom={14}
      scrollWheelZoom={false}
      dragging={false}
      zoomControl={false}
    >
      <TileLayer url={tileUrl} />
      <Polyline
        positions={log.track.map(p => [p.lat, p.lng] as [number, number])}
        pathOptions={{ color: '#3B82FD', weight: 3 }}
      />
      {/* Start marker */}
      <Marker position={[log.track[0].lat, log.track[0].lng]}
        icon={greenIcon} />
      {/* End marker */}
      <Marker position={[log.track[log.track.length - 1].lat, log.track[log.track.length - 1].lng]}
        icon={redIcon} />
    </MapContainer>
  </div>
)}
```

## Sharing

```typescript
const handleShare = async (log: TrailLog) => {
  const shareText = [
    `🏔️ ${log.title}`,
    `📍 ${log.location || '户外徒步'}`,
    `📏 里程: ${(log.totalDistance! / 1000).toFixed(1)} km`,
    `⏱️ 时长: ${formatDuration(log.movingDuration!)}`,
    `🏃 配速: ${formatPace(log.avgPace!)}`,
  ].join('\n');

  if (navigator.share) {
    // Native Share API (mobile)
    await navigator.share({ title: log.title, text: shareText });
  } else {
    // Clipboard fallback (desktop)
    await navigator.clipboard.writeText(shareText);
    showToast('已复制到剪贴板');
  }
};
```

## Edit & Delete

```typescript
// Update log
await traillogsApi.update(logId, {
  notes: newNotes,
  rating: newRating,
  photos: newPhotos,
});

// Delete log
await traillogsApi.delete(logId);
setLogs(logs.filter(l => l.id !== logId));
```
