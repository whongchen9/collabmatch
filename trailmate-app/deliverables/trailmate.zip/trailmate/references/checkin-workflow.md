# Check-in (签到打卡) Workflow

## Overview

The check-in system is checkpoint-driven. A team leader defines checkpoints on the map, and team members check in at each checkpoint during the hike.

## Lifecycle

```
1. Leader creates checkpoints on map (long-press or "+" mode)
2. Leader starts hike → hikeStatus becomes 'hiking'
3. Members navigate to checkpoints
4. Members check in at each checkpoint (photo + note + GPS verify)
5. CompleteModal shows stats after hike ends
6. TrailLog generated with all check-in records
```

## Data Model

```typescript
interface Checkpoint {
  lat: number;
  lng: number;
  label?: string;
  type?: 'meeting' | 'start' | 'checkpoint' | 'end';
  createdAt: number;
  checkins: CheckinRecord[];
}

interface CheckinRecord {
  userId: string;
  userName: string;
  avatarColor?: string;
  checkedInAt: number;
  photos?: string[];   // max 3 photos per check-in
  notes?: string;      // text note
}
```

Checkpoints are stored in `Group.checkpoints[]`.

## Checkpoint Creation (Leader Only)

### Method 1: Long-press on map (>500ms, <2000ms)

```tsx
// LocationMap.tsx
<MapLongPress
  minDuration={500}
  maxDuration={2000}
  onLongPress={(e) => {
    const { lat, lng } = e.latlng;
    setNewCheckpointPos([lat, lng]);
    setShowAddCheckpoint(true);
  }}
/>
```

### Method 2: Green "+" button → click map

```tsx
// Toggle "add checkpoint mode"
const [addCheckpointMode, setAddCheckpointMode] = useState(false);

// When mode is active, MapClick handler creates checkpoint
const handleMapClick = (e: L.LeafletMouseEvent) => {
  if (!addCheckpointMode) return;
  const { lat, lng } = e.latlng;
  setNewCheckpointPos([lat, lng]);
  setShowAddCheckpoint(true);
  setAddCheckpointMode(false);
};
```

### Add checkpoint form

Both methods trigger a bottom sheet with:
- **Type selector**: meeting / start / checkpoint / end
- **Label**: auto-filled from reverse geocoding, editable
- **Save button**: calls `groupsApi.update(id, { checkpoints: [...existing, newCp] })`

## Check-in Execution

### Trigger flow

```
1. User taps a checkpoint marker on map
2. Popup/Tooltip shows with "打卡签到" button
3. Bottom sheet opens with check-in form
   ├── GPS coordinate display
   ├── Text note input ("记录此刻的心情")
   ├── Photo upload (max 3, auto-compress >800px)
   └── "打卡签到" submit button
```

### Check-in API call

```typescript
// LocationMap.tsx check-in handler
const handleCheckin = async (checkpointIndex: number) => {
  // 1. Get current position
  const pos = await new Promise<GeolocationPosition>((resolve, reject) => {
    navigator.geolocation.getCurrentPosition(resolve, reject, {
      timeout: 10000,
      enableHighAccuracy: true,
    });
  });

  const lat = pos.coords.latitude;
  const lng = pos.coords.longitude;

  // 2. Report location to backend
  await groupsApi.reportLocation(id, lat, lng);

  // 3. Execute check-in
  const result = await groupsApi.checkin(id, checkpointIndex, lat, lng);
  // result.distance = distance from checkpoint in meters
  showToast(`签到成功！距离打卡点 ${Math.round(result.distance)}m`);

  // 4. If photos or notes, re-fetch group to get updated checkins
  if (photos.length > 0 || notes) {
    const updated = await groupsApi.get(id);
    // Write photos/notes into checkpoints[checkpointIndex].checkins
    const updatedCheckpoints = [...updated.checkpoints];
    const myCheckin = updatedCheckpoints[checkpointIndex].checkins.find(
      c => c.userId === user.id
    );
    if (myCheckin) {
      myCheckin.photos = uploadedUrls;
      myCheckin.notes = notes;
    }
    await groupsApi.update(id, { checkpoints: updatedCheckpoints });
  }
};
```

### Photo upload for check-in

```typescript
// Compress if width > 800px
const compressImage = (file: File): Promise<Blob> => {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      let { width, height } = img;
      if (width > 800) {
        height = (800 / width) * height;
        width = 800;
      }
      canvas.width = width;
      canvas.height = height;
      canvas.getContext('2d')!.drawImage(img, 0, 0, width, height);
      canvas.toBlob((blob) => resolve(blob!), 'image/jpeg', 0.8);
    };
    img.src = URL.createObjectURL(file);
  });
};

// Upload to CloudBase storage via API
const uploadedUrls = await Promise.all(
  photos.map(async (file) => {
    const compressed = await compressImage(file);
    const formData = new FormData();
    formData.append('file', compressed);
    const res = await usersApi.uploadImage(formData);
    return res.url;
  })
);
```

## Check-in Progress View (LocationPanel)

### Sorting & highlighting

```typescript
// Sort checkpoints by distance from user (closest first)
const sortedCheckpoints = [...checkpoints]
  .map((cp, idx) => ({
    ...cp,
    index: idx,
    distance: haversineDistance(myLat, myLng, cp.lat, cp.lng),
  }))
  .sort((a, b) => a.distance - b.distance);

// Highlight next un-checked-in checkpoint
const nextCheckpoint = sortedCheckpoints.find(cp =>
  !cp.checkins.some(c => c.userId === user.id)
);
```

### Progress bar per member

```typescript
// Each member's completion
const memberProgress = members.map(member => {
  const checkedIn = checkpoints.filter(cp =>
    cp.checkins.some(c => c.userId === member.id)
  ).length;
  return {
    name: member.name,
    avatarColor: member.avatarColor,
    pct: checkpoints.length > 0 ? (checkedIn / checkpoints.length) * 100 : 0,
    count: `${checkedIn}/${checkpoints.length}`,
  };
});

// Average team progress
const totalCheckins = checkpoints.reduce(
  (sum, cp) => sum + cp.checkins.length, 0
);
const maxCheckins = members.length * checkpoints.length;
const avgProgress = maxCheckins > 0 ? (totalCheckins / maxCheckins) * 100 : 0;
```

## Panel States

LocationPanel has three visual states based on `hikeStatus`:

| Status | Header Style | Content |
|--------|-------------|---------|
| `idle` | "等待出发" with muted gray | Checkpoint list (read-only), add-checkpoint button (leader) |
| `hiking` | "征途中" with green gradient | Sorted checkpoint list, next highlighted, progress bars |
| `completed` | "凯旋而归" with green gradient | Summary stats, link to TrailLog |

## Role-based Permissions

- **Leader**: Can add/remove checkpoints, view all members' check-ins
- **Member**: Can only check in, view own progress + team aggregate
- Check-in is only possible when `hikeStatus === 'hiking'`
- Each checkpoint can be checked in only once per member
