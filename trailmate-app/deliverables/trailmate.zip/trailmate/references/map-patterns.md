# Map & GPS Patterns (TrailMate)

## Tech Stack

- **Map library**: Leaflet via `react-leaflet` v4
- **Tiles**: OpenStreetMap (default), with dark mode tile switching
- **Geolocation**: `navigator.geolocation.getCurrentPosition` / `watchPosition`
- **Reverse geocoding**: OpenStreetMap Nominatim API
- **Distance**: Haversine formula (built-in utility)

## Map Component Architecture

### Three tiers of map components:

| Component | Use Case | Features |
|-----------|----------|----------|
| `MapPanel` | Small embedded map in sidebar | Static markers + popups only |
| `LocationMap` | Full-screen interactive map | GPS tracking, checkpoint CRUD, polyline, check-in |
| `RouteDetail` (inline) | Trail log replay | Read-only polyline + markers |

### `LocationMap` — Full Feature Map

```
LocationMap
├── MapContainer (Leaflet)
├── TileLayer (dark/light switch via useTheme)
├── FitBounds (auto-zoom to contain all markers)
├── FlyTo (animated camera move on checkpoint select)
├── MapLongPress (>500ms, <2000ms → add checkpoint — leader only)
├── MapClick (add checkpoint mode — green "+" button)
├── Marker[] (checkpoint markers, memo-optimized)
├── Marker (my position — blue pulsating dot)
├── Marker[] (teammate positions, with avatar initials)
├── Marker[] (SOS markers — red)
├── Polyline (GPS track line, blue, weight:4, opacity:0.5)
└── BottomSheet (check-in modal, add-checkpoint modal)
```

## GPS Track Recording

### Collection loop (15-second interval)

```typescript
// Pattern: useEffect with interval, only when hikeStatus === 'hiking'
useEffect(() => {
  if (groupData?.hikeStatus !== 'hiking') return;

  const tick = () => {
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const pt = {
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          timestamp: Date.now(),
        };
        addTrackPoint(pt);                              // → Zustand store
        setMyPos([pt.lat, pt.lng]);                     // → local state (map center dot)
        groupsApi.reportLocation(id, pt.lat, pt.lng);   // → backend
      },
      () => {}, // silent fail on error
      { timeout: 10000, enableHighAccuracy: true }
    );
  };

  tick(); // immediate first sample
  const interval = setInterval(tick, 15000);
  return () => clearInterval(interval);
}, [id, groupData?.hikeStatus]);
```

### Key design decisions:

- **15-second interval**: balances battery life vs track resolution
- **Immediate first sample**: no 15s lag on hike start
- **Silent failure**: GPS errors are ignored (tunnels, buildings)
- **Dual persistence**: Zustand store (local) + API (remote)
- **Cleanup on unmount**: interval cleared, track persists in store

### Track rendering on map:

```tsx
{track.length > 1 && (
  <Polyline
    positions={track.map(p => [p.lat, p.lng] as [number, number])}
    pathOptions={{ color: '#3B82FD', weight: 4, opacity: 0.5 }}
  />
)}
```

## Haversine Distance Utility

```typescript
// src/lib/utils.ts
export function haversineDistance(
  lat1: number, lng1: number,
  lat2: number, lng2: number
): number {
  const R = 6371e3; // Earth radius in meters
  const φ1 = (lat1 * Math.PI) / 180;
  const φ2 = (lat2 * Math.PI) / 180;
  const Δφ = ((lat2 - lat1) * Math.PI) / 180;
  const Δλ = ((lng2 - lng1) * Math.PI) / 180;
  const a = Math.sin(Δφ / 2) ** 2 +
            Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  // returns distance in meters
}
```

### Usage for track statistics:

```typescript
// Calculate total GPS distance from track points
let totalDistance = 0;
for (let i = 1; i < track.length; i++) {
  totalDistance += haversineDistance(
    track[i-1].lat, track[i-1].lng,
    track[i].lat, track[i].lng
  );
}
// totalDistance in meters

// Duration from first to last point
const movingDuration = (track[track.length - 1].timestamp - track[0].timestamp) / 1000; // seconds

// Average pace (seconds per km)
const avgPace = totalDistance > 0 ? (movingDuration / (totalDistance / 1000)) : 0;
```

## Reverse Geocoding (Nominatim)

```typescript
const fetchLocationName = async (lat: number, lng: number): Promise<string> => {
  const res = await fetch(
    `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=14&addressdetails=1`
  );
  const data = await res.json();
  // Return first 2 parts of display_name for brevity
  return data.display_name ? data.display_name.split(',').slice(0, 2).join(',') : '';
};
```

**Rate limit warning**: Nominatim has a 1 req/s limit. Cache results when possible.

## Dark Mode Map Tiles

```typescript
const tileUrl = isDark
  ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
  : 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
```

## Checkpoint Markers on Map

Each checkpoint renders as a `Marker` + `Popup` or custom `Tooltip`:

```tsx
checkpoints.map((cp, idx) => (
  <Marker
    key={`${cp.lat}-${cp.lng}-${idx}`}
    position={[cp.lat, cp.lng]}
    icon={cpIcon(cp.type)} // different icon by type: meeting/start/checkpoint/end
  >
    <Popup>
      <div>
        <strong>{cp.label || `打卡点 ${idx + 1}`}</strong>
        <div>类型: {cp.type}</div>
        <button onClick={() => onCheckin(idx)}>打卡签到</button>
      </div>
    </Popup>
  </Marker>
))
```

## Teammate Position Markers

```typescript
// Group.locations[] contains last-known positions of all members
groupData?.locations?.map((loc) => (
  <Marker
    key={loc.userId}
    position={[loc.lat, loc.lng]}
    icon={createAvatarIcon(loc.userName, loc.avatarColor)}
  >
    <Tooltip>{loc.userName}</Tooltip>
  </Marker>
))
```
